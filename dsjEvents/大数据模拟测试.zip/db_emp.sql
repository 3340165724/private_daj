/*
Navicat MySQL Data Transfer

Source Server         : mysql81
Source Server Version : 80018
Source Host           : localhost:3306
Source Database       : db_emp

Target Server Type    : MYSQL
Target Server Version : 80018
File Encoding         : 65001

Date: 2021-11-12 10:10:39
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for t_dept
-- ----------------------------
DROP TABLE IF EXISTS `t_dept`;
CREATE TABLE `t_dept` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `deptName` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of t_dept
-- ----------------------------
INSERT INTO `t_dept` VALUES ('1', '技术部');
INSERT INTO `t_dept` VALUES ('2', '产品部');
INSERT INTO `t_dept` VALUES ('3', '运营部');
INSERT INTO `t_dept` VALUES ('4', '人事部');

-- ----------------------------
-- Table structure for t_emp
-- ----------------------------
DROP TABLE IF EXISTS `t_emp`;
CREATE TABLE `t_emp` (
  `empId` int(11) NOT NULL AUTO_INCREMENT COMMENT '员工编号',
  `empName` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender` char(1) COLLATE utf8mb4_unicode_ci NOT NULL,
  `age` int(4) NOT NULL,
  `deptId` int(6) NOT NULL,
  `inDate` date NOT NULL,
  `tel` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`empId`),
  UNIQUE KEY `tel` (`tel`),
  KEY `index_age` (`age`)
) ENGINE=InnoDB AUTO_INCREMENT=1009 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of t_emp
-- ----------------------------
INSERT INTO `t_emp` VALUES ('1001', '张三', '男', '25', '1', '2020-01-01', '13977641234');
INSERT INTO `t_emp` VALUES ('1002', '李四', '女', '21', '2', '2020-03-10', '14787651234');
INSERT INTO `t_emp` VALUES ('1003', '王五', '男', '30', '1', '2015-01-01', '15998761234');
INSERT INTO `t_emp` VALUES ('1004', '赵六', '男', '27', '1', '2018-10-24', '15877931234');
INSERT INTO `t_emp` VALUES ('1005', '田七', '女', '26', '3', '2019-09-09', '18887641234');
INSERT INTO `t_emp` VALUES ('1006', '贺老三', '男', '36', '2', '2016-01-15', '17377641790');
INSERT INTO `t_emp` VALUES ('1007', '高晓苑', '女', '28', '4', '2020-01-02', '15973641230');
INSERT INTO `t_emp` VALUES ('1008', '吴三', '男', '31', '3', '2018-03-20', '18987647537');

-- ----------------------------
-- Table structure for t_salary
-- ----------------------------
DROP TABLE IF EXISTS `t_salary`;
CREATE TABLE `t_salary` (
  `id` int(11) NOT NULL,
  `emp_id` int(6) NOT NULL,
  `salary` decimal(8,2) NOT NULL COMMENT '基本薪资',
  `bonus` decimal(8,2) NOT NULL COMMENT '绩效奖金',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of t_salary
-- ----------------------------
INSERT INTO `t_salary` VALUES ('1', '1001', '5000.00', '1500.00');
INSERT INTO `t_salary` VALUES ('2', '1002', '3500.00', '800.00');
INSERT INTO `t_salary` VALUES ('3', '1003', '4500.00', '2000.00');
INSERT INTO `t_salary` VALUES ('4', '1004', '6000.00', '4000.00');
INSERT INTO `t_salary` VALUES ('5', '1005', '5200.00', '2700.00');
INSERT INTO `t_salary` VALUES ('6', '1006', '4800.00', '3000.00');
INSERT INTO `t_salary` VALUES ('7', '1007', '3000.00', '1200.00');
INSERT INTO `t_salary` VALUES ('8', '1008', '12000.00', '3100.00');

-- ----------------------------
-- View structure for v_emp_salary
-- ----------------------------
DROP VIEW IF EXISTS `v_emp_salary`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_emp_salary` AS select `e`.`empName` AS `姓名`,`s`.`salary` AS `基本薪资` from (`t_emp` `e` join `t_salary` `s`) where ((`e`.`empId` = `s`.`emp_id`) and (`s`.`salary` > (select avg(`s`.`salary`) from ((`t_salary` `s` join `t_emp` `e`) join `t_dept` `d`) where ((`s`.`emp_id` = `e`.`empId`) and (`e`.`deptId` = `d`.`id`) and (`d`.`deptName` = '产品部'))))) ;

-- ----------------------------
-- View structure for v_sum_salary
-- ----------------------------
DROP VIEW IF EXISTS `v_sum_salary`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_sum_salary` AS select `e`.`empName` AS `员工姓名`,`s`.`salary` AS `基本薪资`,`s`.`bonus` AS `绩效`,(`s`.`salary` + `s`.`bonus`) AS `最终工资` from (`t_emp` `e` join `t_salary` `s`) where (`e`.`empId` = `s`.`emp_id`) ;

-- ----------------------------
-- Procedure structure for proc_max_salary
-- ----------------------------
DROP PROCEDURE IF EXISTS `proc_max_salary`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_max_salary`(
	in _deptName varchar(20),
	out _maxSalary decimal(8,2)
)
    READS SQL DATA
begin
	select max(s.salary) 最高底薪 from t_emp e,t_dept d,t_salary s where e.deptId=d.id and d.deptName=_deptName and e.empId=s.emp_id into _maxSalary;
end
;;
DELIMITER ;
